/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entity.Hotel;
import entity.Klijent;
import entity.Rezervacija;
import java.util.Date;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class RezervacijaControllersTest {

    /**
     * Test of listaRezervacijaPoKlijentu method, of class
     * RezervacijaControllers. proverava listu rezervacija kada je klijent null.
     */
    @Test
    public void testListaRezervacijaPoKlijentu() {
        System.out.println("listaRezervacijaPoKlijentu");
        Klijent k = null;
        List<Rezervacija> expResult = null;
        List<Rezervacija> result = RezervacijaControllers.listaRezervacijaPoKlijentu(k);
        assertEquals(expResult, result);
    }

    /**
     * Test of dodajRezervaciju method, of class RezervacijaControllers.
     * proverava dodavanje rezervacije u bazu.
     */
    @Test
    public void testDodajRezervaciju() {
        System.out.println("dodajRezervaciju");
        Hotel h = HotelController.listaHotela().get(0);
        Klijent k = KlijentControllers.listaKlijenata().get(0);
        String tip = "Dvokrevetna";
        Date din = new Date();
        Date dout = new Date();
        Rezervacija r = new Rezervacija();
        r.setIdHotela(h);
        r.setIdKlijenta(k);
        r.setDatumPrijave(din);
        r.setDatumOdjave(dout);
        r.setTipSobe(tip);
        int size = RezervacijaControllers.listaRezervacija().size();
        RezervacijaControllers.dodajRezervaciju(r);
        int size1 = RezervacijaControllers.listaRezervacija().size();
        assertEquals(size, size1 - 1);
    }
    
    /**
     * Test of dodajRezervaciju method, of class RezervacijaControllers.
     * proverava dodavanje rezervacije u bazu kada je rezervacija null;
     */
    @Test
    public void testDodajRezervaciju1() {
        int size = RezervacijaControllers.listaRezervacija().size();
        RezervacijaControllers.dodajRezervaciju(null);
        int size1 = RezervacijaControllers.listaRezervacija().size();
        assertEquals(size, size1);
    }

    /**
     * Test of updateRezervaciju method, of class RezervacijaControllers.
     * proverava update i vraca na prvobitno stanje
     */
    @Test
    public void testUpdateRezervaciju() {
        int size = RezervacijaControllers.listaRezervacija().size();
        Rezervacija r = RezervacijaControllers.listaRezervacija().get(size - 1);
        String tip = r.getTipSobe();
        Integer o = r.getId();
        String a = "Test";
        Rezervacija n = new Rezervacija();
        n.setIdHotela(r.getIdHotela());
        n.setIdKlijenta(r.getIdKlijenta());
        n.setDatumPrijave(r.getDatumPrijave());
        n.setDatumOdjave(r.getDatumOdjave());
        n.setTipSobe(a);
        RezervacijaControllers.updateRezervaciju(o, n);
        Rezervacija rez = RezervacijaControllers.listaRezervacija().get(size - 1);
        assertEquals(rez.getTipSobe(), "Test");
        n.setTipSobe(r.getTipSobe());
        RezervacijaControllers.updateRezervaciju(o, n);

    }
    
     /**
     * Test of updateRezervaciju method, of class RezervacijaControllers.
     * proverava update kada prosledimo id null.
     */
    @Test
    public void testUpdateRezervaciju1() {
        int size = RezervacijaControllers.listaRezervacija().size();
        Rezervacija r = RezervacijaControllers.listaRezervacija().get(size - 1);
        String tip = r.getTipSobe();
        Integer o = null;
        String a = "Test";
        Rezervacija n = new Rezervacija();
        n.setIdHotela(r.getIdHotela());
        n.setIdKlijenta(r.getIdKlijenta());
        n.setDatumPrijave(r.getDatumPrijave());
        n.setDatumOdjave(r.getDatumOdjave());
        n.setTipSobe(a);
        RezervacijaControllers.updateRezervaciju(o, n);
        Rezervacija rez = RezervacijaControllers.listaRezervacija().get(size - 1);
        assertEquals(rez.getTipSobe(), r.getTipSobe());

    }
    
    /**
     * Test of updateRezervaciju method, of class RezervacijaControllers.
     * proverava update kada prosledimo rezervaciju null.
     */
    @Test
    public void testUpdateRezervaciju2() {
        int size = RezervacijaControllers.listaRezervacija().size();
        Rezervacija r = RezervacijaControllers.listaRezervacija().get(size - 1);
        String tip = r.getTipSobe();
        Integer o = r.getId();
        RezervacijaControllers.updateRezervaciju(o, null);
        Rezervacija rez = RezervacijaControllers.listaRezervacija().get(size - 1);
        assertEquals(rez.getTipSobe(), r.getTipSobe());

    }

    /**
     * Test of obrisiRezervaciju method, of class RezervacijaControllers.
     */
    @Test
    public void testObrisiRezervaciju() {
        int size = RezervacijaControllers.listaRezervacija().size();
        RezervacijaControllers.obrisiRezervaciju(RezervacijaControllers.listaRezervacija().get(size - 1));
        int size1 = RezervacijaControllers.listaRezervacija().size();
        assertEquals(size, size1 + 1);
    }
    
    /**
     * Test of obrisiRezervaciju method, of class RezervacijaControllers.
     * testira metodu kada prosedimo null;
     */
    @Test
    public void testObrisiRezervaciju1() {
        int size = RezervacijaControllers.listaRezervacija().size();
        RezervacijaControllers.obrisiRezervaciju(null);
        int size1 = RezervacijaControllers.listaRezervacija().size();
        assertEquals(size, size1);
    }

    /**
     * Test of pretagaRezervacija method, of class RezervacijaControllers.
     * testira pretragu kada je sve null.
     */
    @Test
    public void testPretagaRezervacija() {
        Hotel hotel = null;
        String tip = null;
        Date din = null;
        List<Rezervacija> expResult = null;
        List<Rezervacija> result = RezervacijaControllers.pretagaRezervacija(hotel, tip, din);
        assertEquals(expResult, result);
        
    }
    
    /**
     * Test of pretagaRezervacija method, of class RezervacijaControllers.
     * testira pretragu kada prosledimo sve parametre za datu rezervaciju.
     */
    @Test
    public void testPretagaRezervacija1() {
        Hotel hotel = RezervacijaControllers.listaRezervacija().get(RezervacijaControllers.listaRezervacija().size()-1).getIdHotela();
        String tip = RezervacijaControllers.listaRezervacija().get(RezervacijaControllers.listaRezervacija().size()-1).getTipSobe();
        Date din = RezervacijaControllers.listaRezervacija().get(RezervacijaControllers.listaRezervacija().size()-1).getDatumPrijave();;
        int expResult = 1; 
        List<Rezervacija> lista = RezervacijaControllers.pretagaRezervacija(hotel, tip, din);
        int result = lista.size();
        assertEquals(expResult, result);
        
    }
    
    /**
     * Test of pretagaRezervacija method, of class RezervacijaControllers.
     * testira pretragu kada prosledimo dva parametra.
     */
    @Test
    public void testPretagaRezervacija2() {
        Hotel hotel = RezervacijaControllers.listaRezervacija().get(RezervacijaControllers.listaRezervacija().size()-1).getIdHotela();
        String tip = null;
        Date din = RezervacijaControllers.listaRezervacija().get(RezervacijaControllers.listaRezervacija().size()-1).getDatumPrijave();
        List<Rezervacija> lista = RezervacijaControllers.pretagaRezervacija(hotel, tip, din);
        assertNotNull(lista);
    }
    
    /**
     * Test of pretagaRezervacija method, of class RezervacijaControllers.
     * testira pretragu kada prosledimo jedan parametar.
     */
    @Test
    public void testPretagaRezervacija3() {
        Hotel hotel = RezervacijaControllers.listaRezervacija().get(RezervacijaControllers.listaRezervacija().size()-1).getIdHotela();
        String tip = null;
        Date din = null;
        List<Rezervacija> lista = RezervacijaControllers.pretagaRezervacija(hotel, tip, din);
        assertNotNull(lista);
        
    }
}
