/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entity.Klijent;
import exceptions.KlijentException;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Uros
 */
public class KlijentControllersTest {

    /**
     * Test of login method, of class KlijentControllers.
     */
    @Test
    public void testLogin() {
        String email = "";
        String password = "";
        Klijent expResult = null;
        Klijent result = KlijentControllers.login(email, password);
        assertEquals(expResult, result);
    }

    /**
     * Test of login method, of class KlijentControllers.
     */
    @Test(expected = NullPointerException.class)
    public void testLogin1() {
        String email = null;
        String password = null;
        Klijent expResult = null;
        Klijent result = KlijentControllers.login(email, password);
        assertEquals(expResult, result);
    }

    /**
     * Test of login method, of class KlijentControllers.
     */
    @Test
    public void testLogin2() {
        String email = "admin@admin.com";
        String password = "Admin123#";
        Klijent k = KlijentControllers.listaKlijenata().get(0);
        Klijent result = KlijentControllers.login(email, password);
        assertEquals(k, result);
    }

    /**
     * Test of register method, of class KlijentControllers.
     */
    @Test
    public void testRegister() {
        Klijent k = null;
        boolean expResult = false;
        boolean result = KlijentControllers.register(k);
        assertEquals(expResult, result);

    }

    /**
     * Test of register method, of class KlijentControllers.
     */
    @Test(expected = KlijentException.class)
    public void testRegister1() throws KlijentException {
        System.out.println("register");
        Klijent k = new Klijent(0, "Test", "Test", "Test", "Test", "Test");
        boolean expResult = false;
        boolean result = KlijentControllers.register(k);
        assertEquals(expResult, result);
    }

    /**
     * Test of register method, of class KlijentControllers.
     */
    @Test
    public void testRegister2() throws KlijentException {
        System.out.println("register");
        Klijent k = new Klijent(0, "Test", "Test", "0654343434", "test@test.com", "Test123#");
        boolean expResult = true;
        boolean result = KlijentControllers.register(k);
        assertEquals(expResult, result);
    }

    /**
     * Test provera da li brise klijenta kad je sve uredu.
     */
    @Test
    public void testObrisiKlijenta() {
        Klijent k = KlijentControllers.listaKlijenata().get(KlijentControllers.listaKlijenata().size() - 1);
        assertEquals(KlijentControllers.obrisiKlijenta(k), true);
    }

    /**
     * Test provera da li brise klijenta kad je klijent null.
     */
    @Test
    public void testObrisiKlijenta1() {
        Klijent k = null;
        assertEquals(KlijentControllers.obrisiKlijenta(k), false);
    }

}
