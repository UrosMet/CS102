/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entity.Hotel;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Uros
 */
public class HotelControllerTest {
    
    /**
     * Test of addHotel method, of class HotelController.
     * ispravan rad
     */
    @Test
    public void testAddHotel() {
        Hotel hotel = new Hotel(0, "HotelTest", "AdresaTest", "TipTest");
        
        HotelController.addHotel(hotel);
        Hotel h = HotelController.listaHotela().get(HotelController.listaHotela().size()-1);
        // TODO review the generated test code and remove the default call to fail.
        assertEquals(h, hotel);
    }
    /**
     * Test of addHotel method, of class HotelController.
     * kada prosledimo null
     */
    @Test
    public void testAddHotel1() {
        Hotel hotel = null;
        Hotel test = HotelController.listaHotela().get(HotelController.listaHotela().size()-1);
        HotelController.addHotel(hotel);
        Hotel h = HotelController.listaHotela().get(HotelController.listaHotela().size()-1);
        // TODO review the generated test code and remove the default call to fail.
        assertEquals(h, test);
    }
    
    /**
     * Testiranje brisanje hotela koji smo dodali pre
     */
    @Test
    public void testObrisiHotel() {
        List<Hotel> lista = HotelController.listaHotela();
        int size = lista.size();
        Hotel hotel = lista.get(size - 1);
        HotelController.obrisiHotel(hotel);
        lista = HotelController.listaHotela();
        // TODO review the generated test code and remove the default call to fail.
        assertEquals(size-1, lista.size());
    }
    /**
     * Testiranje brisanje hotela kada prosledimo null
     */
    @Test
    public void testObrisiHotel1() {
        List<Hotel> lista = HotelController.listaHotela();
        int size = lista.size();
        Hotel hotel = null;
        HotelController.obrisiHotel(hotel);
        lista = HotelController.listaHotela();
        // TODO review the generated test code and remove the default call to fail.
        assertEquals(size, lista.size());
    }
    
    

    
    
}
