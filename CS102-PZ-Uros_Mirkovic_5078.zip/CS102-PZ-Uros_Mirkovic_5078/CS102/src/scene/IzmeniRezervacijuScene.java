/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scene;

import controllers.HotelController;
import controllers.RezervacijaControllers;
import entity.Hotel;
import entity.Klijent;
import entity.Rezervacija;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import util.AlertMessage;

/**
 *
 * @author Uros
 */
public class IzmeniRezervacijuScene extends Application {

    Rezervacija r;
    Klijent k;

    public IzmeniRezervacijuScene(Rezervacija r, Klijent k) {
        this.r = r;
        this.k = k;
    }

    Label naslov = new Label("Izmeni Rezervaciju");
    Label imeHotelaLbl = new Label("Hoteli");
    ComboBox<Hotel> hoteliCmb = new ComboBox<>();
    RadioButton dvokrevetnaButton = new RadioButton("Dvokrevetna");
    RadioButton trokrevetnaButton = new RadioButton("Trokrevetna");
    RadioButton cetvorokrevetnaButton = new RadioButton("Cetvorokrevetna");
    ToggleGroup tg = new ToggleGroup();
    Label dateInLbl = new Label("Datum pocetka:");
    DatePicker dp1 = new DatePicker();
    Label dateOutLbl = new Label("Datum zavrsetka:");
    DatePicker dp2 = new DatePicker();
    Button btn = new Button("Izmeni");
    Hyperlink link = new Hyperlink("Back!");

    @Override
    public void start(Stage primaryStage) {
        naslov.setStyle("-fx-font-size: 30px;\n"
                + "    -fx-font-weight: bold;\n"
                + "    -fx-text-fill: #333333;");
        dvokrevetnaButton.setToggleGroup(tg);
        trokrevetnaButton.setToggleGroup(tg);
        cetvorokrevetnaButton.setToggleGroup(tg);

        for (Hotel h : HotelController.listaHotela()) {
            hoteliCmb.getItems().add(h);
        }

        hoteliCmb.getSelectionModel().select(r.getIdHotela());
        LocalDate ld1 = r.getDatumPrijave().toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        dp1.setValue(ld1);
        LocalDate ld2 = r.getDatumOdjave().toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        dp2.setValue(ld2);

        if (r.getTipSobe().equals("Dvokrevetna")) {
            dvokrevetnaButton.setSelected(true);
        } else if (r.getTipSobe().equals("Trokrevetna")) {
            trokrevetnaButton.setSelected(true);
        } else if (r.getTipSobe().equals("Cetvorokrevetna")) {
            cetvorokrevetnaButton.setSelected(true);
        }

        HBox hb1 = new HBox(imeHotelaLbl, hoteliCmb);
        hb1.setSpacing(10);
        VBox vb1 = new VBox(dvokrevetnaButton, trokrevetnaButton, cetvorokrevetnaButton);
        vb1.setSpacing(10);
        HBox hb2 = new HBox(dateInLbl, dp1);
        hb2.setSpacing(20);
        HBox hb3 = new HBox(dateOutLbl, dp2);
        hb3.setSpacing(10);
        VBox center = new VBox(hb1, vb1, hb2, hb3);
        center.setSpacing(15);
        HBox hb4 = new HBox(link, btn);
        hb4.setAlignment(Pos.CENTER);
        hb4.setSpacing(10);

        btn.setOnMousePressed(e -> {
            if (e.isPrimaryButtonDown()) {
                //pozovi izmeni i vrati se na rezervaciju
                RadioButton rb = (RadioButton) tg.getSelectedToggle();
                String tip = rb.getText();
                if (dp1.getValue() != null && dp2.getValue() != null) {
                    Rezervacija n = new Rezervacija();
                    n.setIdHotela(hoteliCmb.getValue());
                    n.setTipSobe(tip);
                    Date din = Date.from(dp1.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
                    Date dout = Date.from(dp2.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
                    n.setDatumPrijave(din);
                    n.setDatumOdjave(dout);
                    RezervacijaControllers.updateRezervaciju(r.getId(), n);
                    AlertMessage.infoMessage("Uspesno izmenjena rezervacija");
                    new RezervacijeScene(k).start(primaryStage);
                }else{
                    AlertMessage.warningMessage("Odaberite datum!");
                }

            }
        });

        link.setOnMousePressed(e -> {
            if (e.isPrimaryButtonDown()) {
                new RezervacijeScene(k).start(primaryStage);
            }
        });

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));
        root.setTop(naslov);
        root.setCenter(center);
        root.setBottom(hb4);

        BorderPane.setAlignment(naslov, Pos.CENTER);
        BorderPane.setAlignment(btn, Pos.CENTER);

        Scene scene = new Scene(root, 400, 400);

        primaryStage.setTitle("Izmeni Rezervaciju");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}
