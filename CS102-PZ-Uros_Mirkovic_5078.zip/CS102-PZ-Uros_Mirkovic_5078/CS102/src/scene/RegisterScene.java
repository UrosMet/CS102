/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scene;

import controllers.KlijentControllers;
import entity.Klijent;
import exceptions.KlijentException;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import main.NewMain;
import util.AlertMessage;

/**
 *
 * @author Uros
 */
public class RegisterScene extends Application {

    Label naslovLbl = new Label("Register");
    Label imeLbl = new Label("Ime");
    TextField imeTxt = new TextField();
    Label prezimeLbl = new Label("Prezime");
    TextField prezimeTxt = new TextField();
    Label telefonLbl = new Label("Telefon");
    TextField telefonTxt = new TextField();
    Label emailLbl = new Label("Email");
    TextField emailTxt = new TextField();
    Label passwordLbl = new Label("Password ");
    TextField passwordTxt = new PasswordField();
    Label passwordconfirmLbl = new Label("Confirm password");
    TextField passwordconfirmTxt = new PasswordField();
    Hyperlink link = new Hyperlink("Back!");
    Button btn = new Button();

    @Override
    public void start(Stage primaryStage) {
        naslovLbl.setStyle("-fx-font-size: 30px;\n"
                + "    -fx-font-weight: bold;\n"
                + "    -fx-text-fill: #333333;");
        HBox hb1 = new HBox(imeLbl, imeTxt);
        hb1.setSpacing(105);
        hb1.setAlignment(Pos.CENTER_LEFT);
        HBox hb2 = new HBox(prezimeLbl, prezimeTxt);
        hb2.setSpacing(77);
        hb2.setAlignment(Pos.CENTER_LEFT);
        HBox hb6 = new HBox(telefonLbl, telefonTxt);
        hb6.setSpacing(80);
        hb6.setAlignment(Pos.CENTER_LEFT);
        HBox hb3 = new HBox(emailLbl, emailTxt);
        hb3.setSpacing(95);
        hb3.setAlignment(Pos.CENTER_LEFT);
        HBox hb4 = new HBox(passwordLbl, passwordTxt);
        hb4.setSpacing(65);
        hb4.setAlignment(Pos.CENTER_LEFT);
        HBox hb5 = new HBox(passwordconfirmLbl, passwordconfirmTxt);
        hb5.setSpacing(10);
        hb5.setAlignment(Pos.CENTER_LEFT);
        VBox vb = new VBox(hb1, hb2, hb6, hb3, hb4, hb5);
        vb.setSpacing(10);
        vb.setAlignment(Pos.CENTER_LEFT);
        HBox hb8 = new HBox(link, btn);
        hb8.setAlignment(Pos.CENTER);
        hb8.setSpacing(10);

        btn.setOnMousePressed(e -> {
            if (e.isPrimaryButtonDown()) {
                try {
                    Klijent k = new Klijent();
                    k.setIme(imeTxt.getText());
                    k.setPrezime(prezimeTxt.getText());
                    k.setTelefon(telefonTxt.getText());
                    k.setEmail(emailTxt.getText());
                    if (passwordTxt.getText().matches(passwordconfirmTxt.getText())) {
                        k.setPassword(passwordTxt.getText());
                    }
                    k.setAdmin(0);
                    KlijentControllers.register(k);
                    AlertMessage.infoMessage("Uspesna registracija!");
                    new NewMain().start(primaryStage);
                } catch (KlijentException ex) {
                    AlertMessage.warningMessage(ex.getMessage());
                }
            }
        });
        
        link.setOnMousePressed(e->{
            if (e.isPrimaryButtonDown()) {
                new NewMain().start(primaryStage);
            }
        });

        BorderPane root = new BorderPane(vb);
        root.setPadding(new Insets(30));
        root.setTop(naslovLbl);
        btn.setText("Register");
        root.setBottom(hb8);
        BorderPane.setAlignment(naslovLbl, Pos.CENTER);
        BorderPane.setAlignment(btn, Pos.CENTER);

        Scene scene = new Scene(root, 400, 400);

        primaryStage.setTitle("Register");
        primaryStage.setScene(scene);
        primaryStage.getIcons().add(new Image("fav.png"));
        primaryStage.setResizable(false);
        primaryStage.show();
    }

}
