/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scene;

import controllers.HotelController;
import controllers.RezervacijaControllers;
import entity.Hotel;
import entity.Klijent;
import entity.Rezervacija;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import main.NewMain;
import util.AlertMessage;

/**
 *
 * @author Uros
 */
public class RezervacijeScene extends Application {

    private Klijent k;

    public RezervacijeScene(Klijent k) {
        this.k = k;
    }
    Label naslov = new Label();

    RadioButton dvokrevetnaButton = new RadioButton("Dvokrevetna");
    RadioButton trokrevetnaButton = new RadioButton("Trokrevetna");
    RadioButton cetvorokrevetnaButton = new RadioButton("Cetvorokrevetna");
    ToggleGroup tg = new ToggleGroup();
    Label naslov2 = new Label();
    TableView tw = new TableView();
    Label hotelLbl = new Label("Hotel");
    TextField hotelTxt = new TextField();
    Label dateLbl = new Label("Datum");
    DatePicker dp = new DatePicker();

    Button obrisiBtn = new Button();
    Button pretaziBtn = new Button();
    Button izmeniBtn = new Button();
    Button resetBtn = new Button();
    Button dodajRezervacijuBtn = new Button("Dodaj novu rezervaciju!");
    Hyperlink link = new Hyperlink("Logout!");

    String pattern = "MM-dd-yyyy";
    SimpleDateFormat sdf = new SimpleDateFormat(pattern);

    ComboBox<Hotel> hoteliCmb = new ComboBox<>();

    Image lupa = new Image("lupa.png");
    Image kanta = new Image("kanta.png");
    Image edit = new Image("edit.png");
    Image reset = new Image("reset.png");

    @Override
    public void start(Stage primaryStage) {
        if (HotelController.listaHotela().isEmpty()) {
            HotelController.ucitajHotele();
        }
        List<Rezervacija> lista = new ArrayList<>();
        if (k.getAdmin() == 0) {
            lista = RezervacijaControllers.listaRezervacijaPoKlijentu(k);
        } else {
            lista = RezervacijaControllers.listaRezervacija();
        }
        for (Hotel h : HotelController.listaHotela()) {
            hoteliCmb.getItems().add(h);
        }
        ImageView img = new ImageView(lupa);
        img.setFitHeight(20);
        img.setFitWidth(20);
        pretaziBtn.setGraphic(img);
        ImageView img1 = new ImageView(edit);
        img1.setFitHeight(20);
        img1.setFitWidth(20);
        izmeniBtn.setGraphic(img1);
        ImageView img2 = new ImageView(kanta);
        img2.setFitHeight(20);
        img2.setFitWidth(20);
        obrisiBtn.setGraphic(img2);
        ImageView img3 = new ImageView(reset);
        img3.setFitHeight(20);
        img3.setFitWidth(20);
        resetBtn.setGraphic(img3);

        hoteliCmb.setMaxWidth(150);
        obrisiBtn.setDisable(true);
        izmeniBtn.setDisable(true);
        resetBtn.setDisable(true);
        naslov.setText("Welcome " + k.getIme() + "!");
        naslov.setStyle("-fx-font-size: 30px;\n"
                + "    -fx-font-weight: bold;\n"
                + "    -fx-text-fill: #333333;");
        naslov2.setText("Pretraga");
        naslov2.setStyle("-fx-font-size: 22px;\n"
                + "    -fx-font-weight: bold;\n"
                + "    -fx-text-fill: #333333;");
        dvokrevetnaButton.setToggleGroup(tg);
        trokrevetnaButton.setToggleGroup(tg);
        cetvorokrevetnaButton.setToggleGroup(tg);

        HBox hb1 = new HBox(hotelLbl, hoteliCmb);
        hb1.setSpacing(10);
        dp.setMaxWidth(150);
        HBox hb2 = new HBox(dateLbl, dp);
        hb2.setSpacing(10);
        HBox hb3 = new HBox(izmeniBtn, obrisiBtn, resetBtn, pretaziBtn);
        hb3.setSpacing(10);
        HBox bottom = new HBox(link, dodajRezervacijuBtn);

        VBox tip = new VBox(dvokrevetnaButton, trokrevetnaButton, cetvorokrevetnaButton);
        tip.setSpacing(10);
        VBox right = new VBox(naslov2, hb1, tip, hb2, hb3, link);
        right.setSpacing(15);
        right.setPadding(new Insets(10));

        link.setOnMousePressed(e -> {
            new NewMain().start(primaryStage);
        });

        TableColumn<Rezervacija, String> imeHotelaCol = new TableColumn<>("Hotel");
        imeHotelaCol.setMinWidth(100);
        TableColumn<Rezervacija, String> imeKlijentaCol = new TableColumn<>("Klijent");
        imeKlijentaCol.setMinWidth(100);
        TableColumn<Rezervacija, String> tipSobeCol = new TableColumn<>("Tip Sobe");
        tipSobeCol.setMinWidth(100);
        TableColumn<Rezervacija, String> dateInCol = new TableColumn<>("Datum pocetka");
        dateInCol.setMinWidth(150);
        TableColumn<Rezervacija, String> dateOutCol = new TableColumn<>("Datum zavrsetka");
        dateOutCol.setMinWidth(150);

        imeHotelaCol.setCellValueFactory((cell) -> {
            return new SimpleStringProperty(cell.getValue().getIdHotela().getNaziv());
        });
        imeKlijentaCol.setCellValueFactory((cell) -> {
            return new SimpleStringProperty(cell.getValue().getIdKlijenta().getIme());
        });
        tipSobeCol.setCellValueFactory((cell) -> {
            return new SimpleStringProperty(cell.getValue().getTipSobe());
        });
        dateInCol.setCellValueFactory((cell) -> {
            Rezervacija r = cell.getValue();
            String d = sdf.format(r.getDatumPrijave());
            return new SimpleStringProperty(d);
        });
        dateOutCol.setCellValueFactory((cell) -> {
            Rezervacija r = cell.getValue();
            String d = sdf.format(r.getDatumOdjave());
            return new SimpleStringProperty(d);
        });

        tw.getColumns().addAll(imeHotelaCol, imeKlijentaCol, tipSobeCol, dateInCol, dateOutCol);

        for (Rezervacija r : lista) {
            tw.getItems().add(r);
        }

        tw.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                obrisiBtn.setDisable(false);
                izmeniBtn.setDisable(false);
                obrisiBtn.setOnMousePressed(e -> {
                    if (e.isPrimaryButtonDown()) {
                        //pozovi obrisi rezervaciju
                        RezervacijaControllers.obrisiRezervaciju((Rezervacija) newValue);
                        AlertMessage.infoMessage("Uspesno Obrisano!");
                        tw.getItems().remove(newValue);
                    }
                });
                izmeniBtn.setOnMousePressed(e -> {
                    if (e.isPrimaryButtonDown()) {
                        //pozovi novi stage gde se ispise rezervacija i moze da se izmeni
                        new IzmeniRezervacijuScene((Rezervacija) newValue, k).start(primaryStage);
                    }
                });
            }
        });

        dodajRezervacijuBtn.setOnMousePressed(e -> {
            if (e.isPrimaryButtonDown()) {
                new DodajRezervacijuScene(k).start(primaryStage);

            }
        });

        pretaziBtn.setOnMousePressed(e -> {
            if (e.isPrimaryButtonDown()) {
                Hotel hotel = null;
                if (hoteliCmb.getValue() != null) {
                    hotel = hoteliCmb.getValue();
                }

                RadioButton rb = (RadioButton) tg.getSelectedToggle();
                String tipSobe = null;
                if (rb != null) {
                    tipSobe = rb.getText();
                }

                Date din = null;
                if (dp.getValue() != null) {
                    din = Date.from(dp.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
                }
                //pozovi metodu pretrazi
                List<Rezervacija> filter = RezervacijaControllers.pretagaRezervacija(hotel, tipSobe, din);
                if (filter != null) {
                    tw.getItems().clear();

                    for (Rezervacija r : filter) {
                        tw.getItems().add(r);
                    }
                    resetBtn.setDisable(false);
                }

            }
        });

        resetBtn.setOnMousePressed(e -> {
            if (e.isPrimaryButtonDown()) {
                hoteliCmb.setValue(null);

                RadioButton rb = (RadioButton) tg.getSelectedToggle();
                if (rb != null) {
                    rb.setSelected(false);
                }

                dp.setValue(null);
                tw.getItems().clear();
                for (Rezervacija r : RezervacijaControllers.listaRezervacijaPoKlijentu(k)) {
                    tw.getItems().add(r);
                }
                resetBtn.setDisable(true);
            }
        });

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));
        root.setTop(naslov);
        root.setCenter(right);
        root.setLeft(tw);
        root.setBottom(dodajRezervacijuBtn);
        BorderPane.setAlignment(naslov, Pos.TOP_RIGHT);
        BorderPane.setAlignment(right, Pos.CENTER_LEFT);
        BorderPane.setAlignment(dodajRezervacijuBtn, Pos.BOTTOM_RIGHT);

        Scene scene = new Scene(root, 900, 700);

        primaryStage.setTitle("Rezervacije");
        primaryStage.setResizable(false);
        primaryStage.getIcons().add(new Image("fav.png"));
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}
