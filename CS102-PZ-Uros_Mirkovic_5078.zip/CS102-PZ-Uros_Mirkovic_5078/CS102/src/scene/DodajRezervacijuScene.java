/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scene;

import controllers.HotelController;
import controllers.RezervacijaControllers;
import entity.Hotel;
import entity.Klijent;
import entity.Rezervacija;
import java.time.ZoneId;
import java.util.Date;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import util.AlertMessage;

/**
 *
 * @author Uros
 */
public class DodajRezervacijuScene extends Application {

    Klijent k;

    public DodajRezervacijuScene(Klijent k) {
        this.k = k;
    }

    Label naslov = new Label("Dodaj Rezervaciju");
    Label imeHotelaLbl = new Label("Hoteli");
    ComboBox<Hotel> hoteliCmb = new ComboBox<>();
    RadioButton dvokrevetnaButton = new RadioButton("Dvokrevetna");
    RadioButton trokrevetnaButton = new RadioButton("Trokrevetna");
    RadioButton cetvorokrevetnaButton = new RadioButton("Cetvorokrevetna");
    ToggleGroup tg = new ToggleGroup();
    Label dateInLbl = new Label("Datum pocetka:");
    DatePicker dp1 = new DatePicker();
    Label dateOutLbl = new Label("Datum zavrsetka:");
    DatePicker dp2 = new DatePicker();
    Button btn = new Button("Dodaj rezervaciju!");
    Hyperlink link = new Hyperlink("Back!");

    @Override
    public void start(Stage primaryStage) {

        naslov.setStyle("-fx-font-size: 30px;\n"
                + "    -fx-font-weight: bold;\n"
                + "    -fx-text-fill: #333333;");
        dvokrevetnaButton.setToggleGroup(tg);
        trokrevetnaButton.setToggleGroup(tg);
        cetvorokrevetnaButton.setToggleGroup(tg);

        for (Hotel h : HotelController.listaHotela()) {
            hoteliCmb.getItems().add(h);
        }

        HBox hb1 = new HBox(imeHotelaLbl, hoteliCmb);
        hb1.setSpacing(10);
        VBox vb1 = new VBox(dvokrevetnaButton, trokrevetnaButton, cetvorokrevetnaButton);
        vb1.setSpacing(10);
        HBox hb2 = new HBox(dateInLbl, dp1);
        hb2.setSpacing(20);
        HBox hb3 = new HBox(dateOutLbl, dp2);
        hb3.setSpacing(10);
        VBox center = new VBox(hb1, vb1, hb2, hb3);
        center.setSpacing(15);
        HBox hb4 = new HBox(link, btn);
        hb4.setAlignment(Pos.CENTER);
        hb4.setSpacing(10);

        btn.setOnMousePressed(e -> {
            if (e.isPrimaryButtonDown()) {
                //pozovi dodaj rezervaciju
                Rezervacija rez = null;
                if (hoteliCmb.getValue() != null) {
                    Hotel h = hoteliCmb.getValue();
                    RadioButton rb = (RadioButton) tg.getSelectedToggle();
                    if (rb != null) {
                        String tip = rb.getText();
                        if (dp1.getValue() != null) {
                            Date din = Date.from(dp1.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
                            if (dp2.getValue() != null) {
                                Date dout = Date.from(dp2.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
                                rez = new Rezervacija();
                                rez.setIdHotela(h);
                                rez.setTipSobe(tip);
                                rez.setDatumPrijave(din);
                                rez.setDatumOdjave(dout);
                                rez.setIdKlijenta(k);
                            }
                        }

                    }

                }
                if (rez == null) {
                    AlertMessage.warningMessage("Nedovoljno podataka!");
                } else {
                    RezervacijaControllers.dodajRezervaciju(rez);
                    AlertMessage.infoMessage("Uspesno dodata rezervacija");
                    new RezervacijeScene(k).start(primaryStage);
                }

            }
        });

        link.setOnMousePressed(e -> {
            if (e.isPrimaryButtonDown()) {
                new RezervacijeScene(k).start(primaryStage);
            }
        });

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));
        root.setTop(naslov);
        root.setCenter(center);
        root.setBottom(hb4);

        BorderPane.setAlignment(naslov, Pos.CENTER);
        BorderPane.setAlignment(btn, Pos.CENTER);

        Scene scene = new Scene(root, 400, 400);

        primaryStage.setTitle("Dodaj Rezervaciju!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}
