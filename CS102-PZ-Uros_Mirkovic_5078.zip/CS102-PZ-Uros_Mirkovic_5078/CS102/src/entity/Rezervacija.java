/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Uros
 */
@Entity
@Table(name = "rezervacija")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Rezervacija.findAll", query = "SELECT r FROM Rezervacija r")
    , @NamedQuery(name = "Rezervacija.findById", query = "SELECT r FROM Rezervacija r WHERE r.id = :id")
    , @NamedQuery(name = "Rezervacija.findByTipSobe", query = "SELECT r FROM Rezervacija r WHERE r.tipSobe = :tipSobe")
    , @NamedQuery(name = "Rezervacija.findByDatumPrijave", query = "SELECT r FROM Rezervacija r WHERE r.datumPrijave = :datumPrijave")
    , @NamedQuery(name = "Rezervacija.findByDatumOdjave", query = "SELECT r FROM Rezervacija r WHERE r.datumOdjave = :datumOdjave")})
public class Rezervacija implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "tip_sobe")
    private String tipSobe;
    @Basic(optional = false)
    @Column(name = "datum_prijave")
    @Temporal(TemporalType.TIMESTAMP)
    private Date datumPrijave;
    @Basic(optional = false)
    @Column(name = "datum_odjave")
    @Temporal(TemporalType.TIMESTAMP)
    private Date datumOdjave;
    @JoinColumn(name = "id_hotela", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Hotel idHotela;
    @JoinColumn(name = "id_klijenta", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Klijent idKlijenta;

    public Rezervacija() {
    }

    public Rezervacija(Integer id) {
        this.id = id;
    }

    public Rezervacija(Integer id, String tipSobe, Date datumPrijave, Date datumOdjave) {
        this.id = id;
        this.tipSobe = tipSobe;
        this.datumPrijave = datumPrijave;
        this.datumOdjave = datumOdjave;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTipSobe() {
        return tipSobe;
    }

    public void setTipSobe(String tipSobe) {
        this.tipSobe = tipSobe;
    }

    public Date getDatumPrijave() {
        return datumPrijave;
    }

    public void setDatumPrijave(Date datumPrijave) {
        this.datumPrijave = datumPrijave;
    }

    public Date getDatumOdjave() {
        return datumOdjave;
    }

    public void setDatumOdjave(Date datumOdjave) {
        this.datumOdjave = datumOdjave;
    }

    public Hotel getIdHotela() {
        return idHotela;
    }

    public void setIdHotela(Hotel idHotela) {
        this.idHotela = idHotela;
    }

    public Klijent getIdKlijenta() {
        return idKlijenta;
    }

    public void setIdKlijenta(Klijent idKlijenta) {
        this.idKlijenta = idKlijenta;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Rezervacija)) {
            return false;
        }
        Rezervacija other = (Rezervacija) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Rezervacija[ id=" + id + " ]";
    }
    
}
