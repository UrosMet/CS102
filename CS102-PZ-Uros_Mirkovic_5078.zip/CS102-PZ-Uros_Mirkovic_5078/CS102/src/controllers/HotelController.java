package controllers;

import entity.Hotel;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import util.AlertMessage;
import util.HibernateUtil;

/**
 *
 * @author Uros
 */
public class HotelController {

    private static final SessionFactory sf = HibernateUtil.getSessionFactory();

    
    /**
     * Metoda vraca sve hotele iz baze podataka.
     *
     * @return List<Hotel>
     */
    public static List<Hotel> listaHotela() {
        Session session = sf.openSession();
        List<Hotel> lista = new ArrayList<>();
        lista = session.createCriteria(Hotel.class).list();
        session.close();
        return lista;
    }

    
    /**
     * Metoda dodaje jedan hotel u bazu.
     *
     * @param h = Hotel
     */
    public static void addHotel(Hotel h) {
        if (h != null) {
            Session session = sf.openSession();
            Transaction t = null;
            try {
                t = session.beginTransaction();
                session.save(h);
                t.commit();
            } catch (HibernateException ex) {
                t.rollback();
                AlertMessage.warningMessage(ex.getMessage());
            } finally {
                session.close();
            }
        }

    }
    
 
    /**
     * Medota brise hotel iz baze
     * @param h - Hotel
     */
    public static void obrisiHotel(Hotel h){
        if (h != null) {
            Session session = sf.openSession();
        Transaction t = null;
        try{
            t = session.beginTransaction();
            session.delete(h);
            t.commit();
        
        }catch(HibernateException ex){
            t.rollback();
            AlertMessage.warningMessage(ex.getMessage());
        }finally{
            session.close();
        }
        }
        
    }
    

    /**
     * Metoda uzima hotele sa interneta preko biblioteke Jsoup i upisuje ih u
     * bazu podataka.
     */
    public static void ucitajHotele() {
        String url = "https://www.hotels.com/search.do?destination-id=1602053&q-check-in=2022-07-10&q-check-out=2022-07-16&q-rooms=1&q-room-0-adults=2&q-room-0-children=0&sort-order=BEST_SELLER";
        try {
            Document doc = Jsoup.connect(url).get();
            Elements els = doc.select("#main > div._3umLRC > div > div > div._1myav2 > section.RO5S5p > ul > li");
            for (Element e : els) {
                Element r = e.select("div > div._3NQzWW > div._15s9kr > section._2sPUhr > div > h2").first();
                Element g = e.select("div > div._3NQzWW > div._15s9kr > section._2sPUhr > p").first();
                Element k = e.select("div > div._3NQzWW > div._15s9kr > section:nth-child(3) > span._3dNxZB").first();
                Hotel h = new Hotel(0, r.text(), g.text(), k.text());
                addHotel(h);
            }
        } catch (IOException ex) {
            AlertMessage.warningMessage(ex.getMessage());
        }
    }
}
