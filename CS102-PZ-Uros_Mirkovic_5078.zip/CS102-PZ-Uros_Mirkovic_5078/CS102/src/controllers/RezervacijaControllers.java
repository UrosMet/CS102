/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entity.Hotel;
import entity.Klijent;
import entity.Rezervacija;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import util.AlertMessage;
import util.HibernateUtil;

/**
 *
 * @author Uros
 */
public class RezervacijaControllers {

    private static final SessionFactory sf = HibernateUtil.getSessionFactory();

    /**
     * Metoda vraca sve rezervacije iz baze.
     *
     * @return list<KLijent>
     */
    public static List<Rezervacija> listaRezervacija() {
        Session session = sf.openSession();
        List<Rezervacija> lista = new ArrayList<>();
        lista = session.createCriteria(Rezervacija.class).list();
        session.close();
        return lista;
    }

    /**
     * Metoda vraca sve rezervacije jednog klijenta.
     *
     * @param k - Klijent
     * @return list<Klijent>
     */
    public static List<Rezervacija> listaRezervacijaPoKlijentu(Klijent k) {
        if (k != null) {
            Session session = sf.openSession();
            List<Rezervacija> lista = new ArrayList<>();
            lista = session.createCriteria(Rezervacija.class).add(Restrictions.eq("idKlijenta", k)).list();
            session.close();
            return lista;
        }
        return null;
    }

    /**
     * Metoda brise rezervaciju iz baze.
     *
     * @param r - Rezervacija
     */
    public static void obrisiRezervaciju(Rezervacija r) {
        if (r != null) {
            Session session = sf.openSession();
            Transaction t = null;
            try {
                t = session.beginTransaction();
                session.delete(r);
                t.commit();
            } catch (HibernateException ex) {
                t.rollback();
                AlertMessage.warningMessage(ex.getMessage());
            } finally {
                session.close();
            }
        }
    }

    /**
     * Metoda dodaje rezervaciju u bazu.
     *
     * @param r - Rezervacija
     */
    public static void dodajRezervaciju(Rezervacija r) {
        if (r != null) {
            Session session = sf.openSession();
            Transaction t = null;
            try {
                t = session.beginTransaction();
                session.save(r);
                t.commit();
            } catch (HibernateException ex) {
                t.rollback();
                AlertMessage.warningMessage("Neuspesno dodavanje");
            } finally {
                session.close();
            }
        }
    }

    /**
     * Metoda vrsi update preko id rezervacije.
     *
     * @param o - id rezervacije
     * @param n - new value
     */
    public static void updateRezervaciju(Integer o, Rezervacija n) {
        if (o != null && n != null) {
            Session session = sf.openSession();
            Transaction t = null;
            try {
                t = session.beginTransaction();
                Rezervacija r = (Rezervacija) session.get(Rezervacija.class, o);
                r.setIdHotela(n.getIdHotela());
                r.setTipSobe(n.getTipSobe());
                r.setDatumPrijave(n.getDatumPrijave());
                r.setDatumOdjave(n.getDatumOdjave());
                session.update(r);
                t.commit();
            } catch (HibernateException ex) {
                t.rollback();
                AlertMessage.warningMessage(ex.getMessage());
            } finally {
                session.close();
            }
        }

    }

    /**
     * Metoda pretazuje po svim kriterijumima
     *
     * @param hotel - Hotel
     * @param tip - String
     * @param din - Date
     * @return List<Rezervacija>
     */
    public static List<Rezervacija> pretagaRezervacija(Hotel hotel, String tip, Date din) {
        List<Rezervacija> lista = new ArrayList<>();
        Session session = sf.openSession();

        if (hotel != null && tip == null && (din == null)) {
            //pretraga samo po hotelu
            lista = session.createCriteria(Rezervacija.class).add(Restrictions.eq("idHotela", hotel)).list();
            session.close();
            return lista;
        }
        if (hotel != null && tip != null && (din == null)) {
            //pretraga po hotelu i tipu sobe
            lista = session.createCriteria(Rezervacija.class).add(Restrictions.eq("idHotela", hotel))
                    .add(Restrictions.eq("tipSobe", tip))
                    .list();
            session.close();
            return lista;
        }
        if (hotel != null && tip != null && (din != null)) {
            //pretraga po sva tri kriterijuma
            lista = session.createCriteria(Rezervacija.class).add(Restrictions.eq("idHotela", hotel))
                    .add(Restrictions.eq("tipSobe", tip))
                    .add(Restrictions.eq("datumPrijave", din))
                    .list();
            session.close();
            return lista;
        }
        if (hotel != null && tip != null && (din == null)) {
            //pretraga po hotelu i tipu sobe
            lista = session.createCriteria(Rezervacija.class).add(Restrictions.eq("idHotela", hotel))
                    .add(Restrictions.eq("tipSobe", tip))
                    .list();
            session.close();
            return lista;
        }
        if (hotel != null && tip == null && (din != null)) {
            //pretraga po datumu prijave i hotelu
            lista = session.createCriteria(Rezervacija.class).add(Restrictions.eq("idHotela", hotel))
                    .add(Restrictions.eq("datumPrijave", din))
                    .list();
            session.close();
            return lista;
        }
        if (hotel == null && tip != null && (din != null)) {
            //pretraga po tipu sobe i datumu prijave 
            lista = session.createCriteria(Rezervacija.class).add(Restrictions.eq("datumPrijave", din))
                    .add(Restrictions.eq("tipSobe", tip))
                    .list();
            session.close();
            return lista;
        }
        if (hotel == null && tip != null && (din == null)) {
            //pretraga samo po tipu
            lista = session.createCriteria(Rezervacija.class).add(Restrictions.eq("tipSobe", tip)).list();
            session.close();
            return lista;
        }
        if (hotel == null && tip == null && (din != null)) {
            //pretraga samo po datumu
            lista = session.createCriteria(Rezervacija.class).add(Restrictions.eq("datumPrijave", din)).list();
            session.close();
            return lista;
        }
        if (hotel == null && tip == null && din == null) {
            return null;
        }
        return null;

    }
}
