/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entity.Klijent;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import util.AlertMessage;
import util.HibernateUtil;

/**
 *
 * @author Uros
 */
public class KlijentControllers {

    private static final SessionFactory sf = HibernateUtil.getSessionFactory();

    /**
     * Metoda koja vraca sve klijente iz baze
     *
     * @return listaKlijenata
     */
    public static List<Klijent> listaKlijenata() {
        Session session = sf.openSession();
        List<Klijent> lista = new ArrayList<>();
        lista = session.createCriteria(Klijent.class).list();
        session.close();
        return lista;
    }

    /**
     * Metoda koja proverava da li klijent postoji u bazi.
     *
     * @param email
     * @param password
     * @return Klijent-ako postoji
     */
    public static Klijent login(String email, String password) {

        if (!email.isEmpty() && !password.isEmpty()) {
            Session session = sf.openSession();
            List<Klijent> lista = new ArrayList<>();
            lista = session.createCriteria(Klijent.class)
                    .add(Restrictions.like("email", email))
                    .add(Restrictions.like("password", Klijent.md5(password)))
                    .list();
            if (lista.size() == 1) {
                return lista.get(0);
            } else {
                return null;
            }
        }
        return null;
    }

    /**
     * Metoda koja registruje klijenta u bazi.
     *
     * @param k - Novi klijent
     * @return true/false
     */
    public static boolean register(Klijent k) {
        if (k != null) {
            Session session = sf.openSession();
            Transaction t = null;
            try {
                t = session.beginTransaction();
                session.save(k);
                t.commit();
            } catch (HibernateException ex) {
                t.rollback();
                AlertMessage.warningMessage(ex.getMessage());
            } finally {
                session.close();
            }
            return true;
        }
        return false;
    }
    
    /**
     * Metoda brise klijenta iz baze.
     * @param k - Klijent
     * @return boolean
     */
    public static boolean obrisiKlijenta(Klijent k) {
        if (k != null) {
            Session session = sf.openSession();
            Transaction t = null;
            try {
                t = session.beginTransaction();
                session.delete(k);
                t.commit();
                return true;
            } catch (HibernateException ex) {
                t.rollback();
                AlertMessage.warningMessage(ex.getMessage());
                return false;
            }finally{
                session.close();
            }

        }
        return false;
    }
}
