/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import controllers.KlijentControllers;
import entity.Klijent;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import scene.RegisterScene;
import scene.RezervacijeScene;
import util.AlertMessage;

/**
 *
 * @author Uros
 */
public class NewMain extends Application {
    
    Label naslovLbl = new Label("Login");
    Label usernameLbl = new Label("Email");
    TextField usernameTxt = new TextField();
    Label passwordLbl = new Label("Password ");
    TextField passwordTxt = new PasswordField();
    Button btn = new Button();
    Hyperlink link = new Hyperlink("Register here!");
    
    @Override
    public void start(Stage primaryStage) {
        naslovLbl.setStyle("-fx-font-size: 30px;\n"
                + "    -fx-font-weight: bold;\n"
                + "    -fx-text-fill: #333333;");
        usernameTxt.setPromptText("email");
        HBox hb1 = new HBox(usernameLbl, usernameTxt);
        hb1.setSpacing(40);
        hb1.setAlignment(Pos.CENTER);
        passwordTxt.setPromptText("**********");
        HBox hb2 = new HBox(passwordLbl, passwordTxt);
        hb2.setAlignment(Pos.CENTER);
        hb2.setSpacing(10);
        HBox hb3 = new HBox(link,btn);
        hb3.setAlignment(Pos.CENTER);
        hb3.setSpacing(10);
        VBox vb = new VBox(hb1, hb2);
        vb.setSpacing(10);
        vb.setAlignment(Pos.CENTER);
        btn.setText("Login");
        
        
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(30));
        BorderPane.setAlignment(naslovLbl, Pos.CENTER);
        BorderPane.setAlignment(btn, Pos.CENTER_RIGHT);
        root.setTop(naslovLbl);
        root.setCenter(vb);
        root.setBottom(hb3);
        
        link.setOnMousePressed(e->{
            if (e.isPrimaryButtonDown()) {
                new RegisterScene().start(primaryStage);
            }
        });
        
        btn.setOnMousePressed(e->{
            if (e.isPrimaryButtonDown()) {
                Klijent k = KlijentControllers.login(usernameTxt.getText(), passwordTxt.getText());
                if (k != null) {
                    AlertMessage.infoMessage("Uspesno Logovanje!");
                    new RezervacijeScene(k).start(primaryStage);
                }else{
                    AlertMessage.warningMessage("Neispravni podaci!");
                }
            }
        });
        
        Scene scene = new Scene(root, 350, 300);
        
        
        primaryStage.setTitle("Login");
        primaryStage.setResizable(false);
        primaryStage.getIcons().add(new Image("fav.png"));
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
